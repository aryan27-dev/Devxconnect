import Navbarhome from "../components/Navbarhome";

export default function Bulk() {
    return (
        <div>
            <Navbarhome id={1} name="Project" year={2023} techStack={["React", "TypeScript"]} />
        </div>
    )
}