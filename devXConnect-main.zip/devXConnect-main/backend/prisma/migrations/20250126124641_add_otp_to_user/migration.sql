-- AlterTable
ALTER TABLE "User" ADD COLUMN     "otp" TEXT;
